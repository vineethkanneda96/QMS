package com.capgemini.trg.web;

@SpringBootApplication
public class Client {

	public static void main(String[] args) {
		SpringApplication.run(Client.class,args);

	}

}
