package com.capgi.parallelproject.dao;

import java.util.List;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.exception.CustomerNotFound;

public interface ICustomerDAO {
	public boolean createAccount(Customer c) throws CustomerNotFound;
	
	public Customer displayCustomer(int accNo);

	public double showBalance(int cid, int pin) throws CustomerNotFound;

	public double deposit(Customer c,int accountNo,int pin, double amount) throws CustomerNotFound;

	public double withDraw(Customer c,int accountNo,int pin, double amount) throws CustomerNotFound;

	public boolean fundTransfer(Customer c,Customer b,double amount, int acc1, int acc2, int pin1) throws CustomerNotFound;

	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFound;
}
