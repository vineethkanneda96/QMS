package com.capgi.parallelproject.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.dao.CustomerDAOImp;
import com.capgi.parallelproject.exception.CustomerNotFound;

public class CustomerServiceImp implements ICustomerService {
    CustomerDAOImp dao=new CustomerDAOImp();
	@Override
	public boolean createAccount(Customer c) throws CustomerNotFound{
		// TODO Auto-generated method stub
		  return dao.createAccount(c);
	}

	@Override
	public double showBalance(int cid,int pin) throws CustomerNotFound{
		// TODO Auto-generated method stub
		return dao.showBalance(cid,pin);
	}

	@Override
	public double deposit(Customer c,int accountNo,int pin, double deposit) throws CustomerNotFound{
		// TODO Auto-generated method stub
		
		return dao.deposit(c,accountNo,pin,deposit);
	}

	@Override
	public double withDraw(Customer c,int accountNo,int pin, double amount) throws CustomerNotFound {
		return dao.withDraw(c,accountNo,pin, amount);
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,double amount,int acc1, int acc2, int pin1) throws CustomerNotFound {
		return dao.fundTransfer(c,b,amount,acc1,acc2,pin1);
	}

	@Override
	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid, pin);
	}

	public  String toTitleCase(String givenString) {
	    String[] arr = givenString.split(" ");
	    StringBuffer sb = new StringBuffer();

	    for (int i = 0; i < arr.length; i++) {
	        sb.append(Character.toUpperCase(arr[i].charAt(0)))
	            .append(arr[i].substring(1)).append(" ");
	    }          
	    return sb.toString().trim();
	}  
	public boolean validateOpeningBalance(double openingBalance){
		
		boolean flag=true;
		if(openingBalance<=0){
			flag=false;
		}
		return flag;
	}
	public boolean validateAccountNumber(int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.validateAccountNumber(cid);
	}
	public boolean validatePin(int pin,int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.validatePin(pin,cid);
	}

	@Override
	public Customer displayCustomer(int accNo) {
		// TODO Auto-generated method stub
		return dao.displayCustomer(accNo);
	}

    public boolean validateCustomerFirstName(String customerFirstName){
    	boolean flag=false;
    	Pattern firstName=Pattern.compile("^[A-Za-z]{1,}\\s?[A-Za-z]{0,}$");
    	Matcher mtch = firstName.matcher(customerFirstName);
		if(customerFirstName.length()>=2&&mtch.matches()){
			flag=true;
		}
    return flag;
    }

	public boolean validateCustomerMiddleName(String customerMiddleName) {
		// TODO Auto-generated method stub
		boolean flag=false;
		Pattern middleName=Pattern.compile("[a-zA-Z\\n ]*$");
    	Matcher mtch = middleName.matcher(customerMiddleName);
		if(mtch.matches()){
			flag=true;
		}
    return flag;
	}

	public boolean validateCustomerLastName(String customerLastName) {
		// TODO Auto-generated method stub
		boolean flag=false;
    	Pattern lastName=Pattern.compile("^[A-Za-z]{1,}\\s?[A-Za-z]{0,}$");
    	Matcher mtch = lastName.matcher(customerLastName);
		if(customerLastName.length()>=0&&mtch.matches()){
			flag=true;
		}
    return flag;
	}

	public boolean validateMobileNo(String mobileNo, Customer cus) {
		// TODO Auto-generated method stub
		Pattern mobileNo1=Pattern.compile("^[+(0/91)-]?[7-9][0-9]{9}"); 
		Matcher mobileMatch=mobileNo1.matcher(mobileNo);
		return mobileMatch.matches();
	}

	public boolean validateAge(String age) {
		// TODO Auto-generated method stub
		Pattern age1=Pattern.compile("^[0-9]{1,2}$");
    	Matcher mtch = age1.matcher(age);
        return mtch.matches();
	}

	public boolean validateAddress(String address) {
		// TODO Auto-generated method stub
		Pattern address1=Pattern.compile("^[#.0-9 a-zA-Z,\\u0020-]+$");
    	Matcher mtch = address1.matcher(address);
        return mtch.matches();
	}
	public boolean validatePinCode(String address) {
		// TODO Auto-generated method stub
		Pattern address1=Pattern.compile("^[0-9]{6}$");
    	Matcher mtch = address1.matcher(address);
        return mtch.matches();
	}

	public boolean validateGender(String gender,Customer c) {
		// TODO Auto-generated method stub
		if(gender.equals("M")||(gender.equals("MALE"))){
			c.setGender("Male");
			return true;
		}else if(gender.matches("F")||gender.matches("FEMALE")){
			c.setGender("Female");
			return true;
		}
		return false;
	}
	public boolean validateEmailAddress(String email) {
        Pattern p = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
        Matcher m = p.matcher(email);
        return m.matches();
 }

	public int validatePanNo(String panNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
        Matcher m = p.matcher(panNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}

	public int validateAadharNo(String aadharNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[0-9]{12}");
        Matcher m = p.matcher(aadharNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
    }

	public int validateVoterId(String voterId) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{3}[0-9]{7}");
        Matcher m = p.matcher(voterId);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}

	public int validatedrivingLicenseNo(String drivingLicenseNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{2}[0-9]{13}");
        Matcher m = p.matcher(drivingLicenseNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}
	public boolean validateAccountType(String accountType,Customer c) {
		// TODO Auto-generated method stub
		if(accountType.equals("S")||(accountType.equals("SAVINGSACCOUNT"))){
			c.setAccountType("Savings Account");
			return true;
		}else if(accountType.matches("C")||accountType.matches("CURRENTACCOUNT")){
			c.setAccountType("Current Account");
			return true;
		}
		return false;
	}

	public boolean validateDateOfBirth(String dob) {
		Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[-/.](0[1-9]|1[012])[-/.](19|20)\\d\\d$");
        Matcher m = p.matcher(dob);
        if(m.matches()){
        	return true;
        }
		return false;
	}
}