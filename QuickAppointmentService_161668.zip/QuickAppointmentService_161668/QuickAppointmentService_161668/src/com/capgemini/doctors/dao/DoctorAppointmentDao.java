package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	Map<Integer,DoctorAppointment> appointments=new HashMap<Integer,DoctorAppointment>();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		int key=doctorAppointment.getAppointmentId();
	    appointments.put(key, doctorAppointment);
	    if(appointments.containsValue(doctorAppointment)){
	    	return 1;
	    }
	    return 0;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
        DoctorAppointment c1=null;
		for (DoctorAppointment c : appointments.values()) {
		  if(c.getAppointmentId()==appointmentId){
		        System.out.println(" Patient Name: "+c.getPatientName()+"\n Appointment Status: "+c.getAppointmentStatus()+"\n Doctor Name:"+c.getDoctorName());
		        System.out.println("*Appointment date and Time, along with Doctor's Phone number will be shared shortly with you..");
		}
		}
		return c1;
	}
	
	@Override
	public DoctorAppointment displayPatient(int appointmentId) {
		// TODO Auto-generated method stub
		DoctorAppointment custo=null;
		for (DoctorAppointment c : appointments.values()) {
			if ((c.getAppointmentId()==appointmentId) ){
				custo=c;
			}
		}
		return custo;
	}

	public boolean validateAppointmentId(long cid) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for (DoctorAppointment c : appointments.values()) {
			if (c.getAppointmentId()==cid) {
				flag=true;;
			}
			
		}
		return flag;
	}

}
