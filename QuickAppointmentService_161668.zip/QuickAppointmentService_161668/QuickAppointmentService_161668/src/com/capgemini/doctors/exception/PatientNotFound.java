package com.capgemini.doctors.exception;

public class PatientNotFound extends Exception{
	
	 public PatientNotFound(String message){
	    	super(message);
	      }
}
